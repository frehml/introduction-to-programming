//
// Created by Frederic on 06/12/2020.
//

#include "Personage.h"
#include "Vak.h"
#include <string>
#include "Ghost.h"
using namespace std;


    Vak* vak;

    Personage::Personage(Vak* v){
        vak = v;
    }

    Vak* Personage::getVak(){
        return vak;
    };

    bool Personage::botstMet(Personage* p){
        if (getVak() == p->getVak())
            return true;
        return false;
    }

    int Personage::volgende_rij_positie(char richting){
        int rij = getVak()->getRij();
        if (richting == 'B')
            rij--;
        else if (richting == 'O')
            rij++;

        return rij;
    }

    int Personage::volgende_kolom_positie(char richting){
        int kol = getVak()->getKolom();
        if (richting == 'L')
            kol--;
        else if (richting == 'R')
            kol++;


        return kol;
    }

    void Personage::verplaats(Vak* nieuw_vak){
        vak = nieuw_vak;
    }

    string Personage::toString() {
        return "O";
    }
