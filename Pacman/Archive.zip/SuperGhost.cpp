//
// Created by Frederic Hamelink on 06/12/2020.
//

#include "SuperGhost.h"
#include "Ghost.h"
#include "Personage.h"
    SuperGhost::SuperGhost(Vak* vak) : Ghost(vak){

    }

    char SuperGhost::toString(){
        return 'S';
    }

    int SuperGhost::volgende_rij_positie(char richting){
        int rij = getVak()->getRij();

        if (richting == 'B')
            rij = rij-((rand() % 2) + 1);
        else if (richting == 'O')
            rij = rij+((rand() % 2) + 1);


        return rij;
    }

    int SuperGhost::volgende_kolom_positie(char richting){
        int kol = getVak()->getKolom();
        if (richting == 'L')
            kol = kol-((rand() % 2) + 1);
        else if (richting == 'R')
            kol = kol+((rand() % 2) + 1);

        return kol;
    }