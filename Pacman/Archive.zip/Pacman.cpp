//
// Created by Frederic Hamelink on 06/12/2020.
//
#include "Pacman.h"
#include <string>
#include "Personage.h"

using namespace std;
    Pacman::Pacman(Vak* vak) : Personage(vak){

    }
    string Pacman::toString(){
        return "O";
    }
