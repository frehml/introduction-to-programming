//
// Created by Frederic Hamelink on 06/12/2020.
//

#include "Muur.h"
#include <string>
using namespace std;

Muur::Muur(int x, int y) : Vak(x, y){

}

bool Muur::isBegaanbaar(){
    return false;
}

bool Muur::isVrij(){
    return false;
}

string Muur::toString(){
    return "M";
}