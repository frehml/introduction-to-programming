//
// Created by Frederic on 06/12/2020.
//

#include "Vak.h"

    Vak::Vak(int x, int y){
        rij = x;
        kolom = y;
    }

    int Vak::getKolom()
    {
        return kolom;
    }

    int Vak::getRij()
    {
        return rij;
    }