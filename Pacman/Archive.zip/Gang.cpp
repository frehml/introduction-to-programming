//
// Created by Frederic Hamelink on 06/12/2020.
//

#include "Gang.h"
#include <string>
using namespace std;

    Gang::Gang(int x, int y) : Vak(x, y){
        personage = nullptr;
        heeft_voedsel = true;
    }

    bool Gang::isBegaanbaar(){
        return true;
    }

    bool Gang::isVrij(){
        if (personage == nullptr)
            return true;
        return false;
    }

    void Gang::plaats_personage(Personage* p){
        personage = p;
    }

    void Gang::verwijder_personage(Personage* p){
        p = nullptr;
    }

    bool Gang::heeftVoedsel(){
        return heeftVoedsel();
    }

    void Gang::eetVoedsel(){
        heeft_voedsel = false;
    }

    string Gang::toString(){
        if (personage != nullptr)
            return personage->toString();
        else if (heeft_voedsel)
            return ".";
        else
            return "";
    }