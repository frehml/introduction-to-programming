//
// Created by Frederic on 06/12/2020.
//

#ifndef HUISTAAK8_VAK_H
#define HUISTAAK8_VAK_H


class Vak{
public:
    int rij;
    int kolom;

    Vak(int x, int y);

    int getKolom();

    int getRij();
};


#endif //HUISTAAK8_VAK_H
